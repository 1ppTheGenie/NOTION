-- =====================================================
-- TASK MANAGER DATABASE SCHEMA
-- Run this against your MSSQL instance first
-- =====================================================

-- Create database (skip if using existing)
IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'TaskManager')
BEGIN
    CREATE DATABASE TaskManager;
END
GO

USE TaskManager;
GO

-- Users table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Users')
BEGIN
    CREATE TABLE Users (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Email NVARCHAR(255) NOT NULL UNIQUE,
        DisplayName NVARCHAR(100) NOT NULL,
        PasswordHash NVARCHAR(255) NOT NULL,
        IsActive BIT DEFAULT 1,
        CreatedAt DATETIME2 DEFAULT GETUTCDATE(),
        UpdatedAt DATETIME2 DEFAULT GETUTCDATE()
    );
END
GO

-- Projects table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Projects')
BEGIN
    CREATE TABLE Projects (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Name NVARCHAR(200) NOT NULL,
        Description NVARCHAR(MAX),
        Status NVARCHAR(20) DEFAULT 'Active',
        OwnerId INT NOT NULL,
        CreatedAt DATETIME2 DEFAULT GETUTCDATE(),
        UpdatedAt DATETIME2 DEFAULT GETUTCDATE(),
        CONSTRAINT FK_Projects_Owner FOREIGN KEY (OwnerId) REFERENCES Users(Id)
    );
END
GO

-- Task statuses
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'TaskStatuses')
BEGIN
    CREATE TABLE TaskStatuses (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Name NVARCHAR(50) NOT NULL,
        DisplayOrder INT NOT NULL,
        Color NVARCHAR(7) DEFAULT '#6B7280'
    );

    INSERT INTO TaskStatuses (Name, DisplayOrder, Color) VALUES 
        ('Backlog', 1, '#6B7280'),
        ('To Do', 2, '#3B82F6'),
        ('In Progress', 3, '#F59E0B'),
        ('In Review', 4, '#8B5CF6'),
        ('Done', 5, '#10B981');
END
GO

-- Tasks table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Tasks')
BEGIN
    CREATE TABLE Tasks (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Title NVARCHAR(300) NOT NULL,
        Description NVARCHAR(MAX),
        ProjectId INT NOT NULL,
        StatusId INT NOT NULL DEFAULT 1,
        AssigneeId INT NULL,
        Priority INT DEFAULT 2,
        DueDate DATETIME2 NULL,
        DisplayOrder INT DEFAULT 0,
        CreatedById INT NOT NULL,
        CreatedAt DATETIME2 DEFAULT GETUTCDATE(),
        UpdatedAt DATETIME2 DEFAULT GETUTCDATE(),
        CONSTRAINT FK_Tasks_Project FOREIGN KEY (ProjectId) REFERENCES Projects(Id),
        CONSTRAINT FK_Tasks_Status FOREIGN KEY (StatusId) REFERENCES TaskStatuses(Id),
        CONSTRAINT FK_Tasks_Assignee FOREIGN KEY (AssigneeId) REFERENCES Users(Id),
        CONSTRAINT FK_Tasks_CreatedBy FOREIGN KEY (CreatedById) REFERENCES Users(Id)
    );

    CREATE INDEX IX_Tasks_ProjectId ON Tasks(ProjectId);
    CREATE INDEX IX_Tasks_StatusId ON Tasks(StatusId);
    CREATE INDEX IX_Tasks_AssigneeId ON Tasks(AssigneeId);
END
GO

-- Task comments
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'TaskComments')
BEGIN
    CREATE TABLE TaskComments (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        TaskId INT NOT NULL,
        UserId INT NOT NULL,
        Content NVARCHAR(MAX) NOT NULL,
        CreatedAt DATETIME2 DEFAULT GETUTCDATE(),
        CONSTRAINT FK_Comments_Task FOREIGN KEY (TaskId) REFERENCES Tasks(Id) ON DELETE CASCADE,
        CONSTRAINT FK_Comments_User FOREIGN KEY (UserId) REFERENCES Users(Id)
    );
END
GO

-- Project members
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'ProjectMembers')
BEGIN
    CREATE TABLE ProjectMembers (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        ProjectId INT NOT NULL,
        UserId INT NOT NULL,
        Role NVARCHAR(20) DEFAULT 'Member',
        JoinedAt DATETIME2 DEFAULT GETUTCDATE(),
        CONSTRAINT FK_Members_Project FOREIGN KEY (ProjectId) REFERENCES Projects(Id) ON DELETE CASCADE,
        CONSTRAINT FK_Members_User FOREIGN KEY (UserId) REFERENCES Users(Id),
        CONSTRAINT UQ_ProjectMember UNIQUE (ProjectId, UserId)
    );
END
GO

-- Insert a default admin user (password: admin123)
-- BCrypt hash for 'admin123'
IF NOT EXISTS (SELECT * FROM Users WHERE Email = 'admin@localhost')
BEGIN
    INSERT INTO Users (Email, DisplayName, PasswordHash)
    VALUES ('admin@localhost', 'Admin', '$2a$11$rBNdFdDpLCcE6GwmWGEKE.Q8DLz3hy3z7hYxlQFqY7mT8xJhP1qnW');
    
    -- Create a default project
    DECLARE @UserId INT = SCOPE_IDENTITY();
    INSERT INTO Projects (Name, Description, OwnerId)
    VALUES ('My First Project', 'Default project to get started', @UserId);
    
    DECLARE @ProjectId INT = SCOPE_IDENTITY();
    INSERT INTO ProjectMembers (ProjectId, UserId, Role)
    VALUES (@ProjectId, @UserId, 'Owner');
END
GO

PRINT 'Schema created successfully!';
PRINT 'Default login: admin@localhost / admin123';
GO
