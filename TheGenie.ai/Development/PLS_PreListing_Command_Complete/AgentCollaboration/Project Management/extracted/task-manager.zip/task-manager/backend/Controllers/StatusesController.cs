using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskManager.Api.Data;
using TaskManager.Api.Models;

namespace TaskManager.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class StatusesController : ControllerBase
{
    private readonly AppDbContext _db;

    public StatusesController(AppDbContext db)
    {
        _db = db;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<TaskStatus>>> GetStatuses()
    {
        return await _db.TaskStatuses.OrderBy(s => s.DisplayOrder).ToListAsync();
    }
}
