using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TaskManager.Api.Models;

[Table("Tasks")]
public class TaskItem
{
    public int Id { get; set; }
    
    [Required, MaxLength(300)]
    public string Title { get; set; } = string.Empty;
    
    public string? Description { get; set; }
    
    public int ProjectId { get; set; }
    public Project? Project { get; set; }
    
    public int StatusId { get; set; } = 1;
    public TaskStatus? Status { get; set; }
    
    public int? AssigneeId { get; set; }
    public User? Assignee { get; set; }
    
    public int Priority { get; set; } = 2; // 1=Low, 2=Medium, 3=High, 4=Urgent
    
    public DateTime? DueDate { get; set; }
    
    public int DisplayOrder { get; set; } = 0;
    
    public int CreatedById { get; set; }
    public User? CreatedBy { get; set; }
    
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
}
