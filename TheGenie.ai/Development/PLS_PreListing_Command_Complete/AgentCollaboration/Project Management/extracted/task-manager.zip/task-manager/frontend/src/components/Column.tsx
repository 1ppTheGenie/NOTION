import { useDroppable } from '@dnd-kit/core';
import type { Task, TaskStatus } from '../types';
import TaskCard from './TaskCard';
import { Plus } from 'lucide-react';

interface ColumnProps {
  status: TaskStatus;
  tasks: Task[];
  onTaskClick: (task: Task) => void;
  onAddClick: () => void;
}

export default function Column({ status, tasks, onTaskClick, onAddClick }: ColumnProps) {
  const { setNodeRef, isOver } = useDroppable({
    id: `column-${status.id}`,
  });

  return (
    <div
      ref={setNodeRef}
      className={`
        w-72 flex-shrink-0 bg-gray-200 rounded-xl p-3 flex flex-col
        ${isOver ? 'bg-gray-300' : ''}
        transition-colors
      `}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div 
            className="w-3 h-3 rounded-full" 
            style={{ backgroundColor: status.color }}
          />
          <h3 className="font-semibold text-gray-700">{status.name}</h3>
          <span className="text-sm text-gray-500 bg-gray-300 px-2 py-0.5 rounded-full">
            {tasks.length}
          </span>
        </div>
        <button
          onClick={onAddClick}
          className="p-1 text-gray-500 hover:text-gray-700 hover:bg-gray-300 rounded transition"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      {/* Tasks */}
      <div className="flex-1 space-y-2 overflow-y-auto min-h-[200px]">
        {tasks.map((task) => (
          <TaskCard
            key={task.id}
            task={task}
            onClick={() => onTaskClick(task)}
          />
        ))}
      </div>
    </div>
  );
}
