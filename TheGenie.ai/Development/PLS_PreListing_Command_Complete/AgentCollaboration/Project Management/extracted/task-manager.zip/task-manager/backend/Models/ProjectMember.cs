using System.ComponentModel.DataAnnotations;

namespace TaskManager.Api.Models;

public class ProjectMember
{
    public int Id { get; set; }
    
    public int ProjectId { get; set; }
    public Project? Project { get; set; }
    
    public int UserId { get; set; }
    public User? User { get; set; }
    
    [MaxLength(20)]
    public string Role { get; set; } = "Member";
    
    public DateTime JoinedAt { get; set; } = DateTime.UtcNow;
}
