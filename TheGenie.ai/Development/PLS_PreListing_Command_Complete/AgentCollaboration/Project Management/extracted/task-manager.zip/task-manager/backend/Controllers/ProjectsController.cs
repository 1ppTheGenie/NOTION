using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using TaskManager.Api.Data;
using TaskManager.Api.DTOs;
using TaskManager.Api.Models;

namespace TaskManager.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ProjectsController : ControllerBase
{
    private readonly AppDbContext _db;

    public ProjectsController(AppDbContext db)
    {
        _db = db;
    }

    private int GetUserId() => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    [HttpGet]
    public async Task<ActionResult<IEnumerable<ProjectResponse>>> GetProjects()
    {
        var userId = GetUserId();
        
        var projects = await _db.Projects
            .Include(p => p.Owner)
            .Include(p => p.Tasks)
            .Where(p => p.OwnerId == userId || p.Members.Any(m => m.UserId == userId))
            .Select(p => new ProjectResponse(
                p.Id,
                p.Name,
                p.Description,
                p.Status,
                p.OwnerId,
                p.Owner!.DisplayName,
                p.Tasks.Count,
                p.CreatedAt
            ))
            .ToListAsync();

        return Ok(projects);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<ProjectResponse>> GetProject(int id)
    {
        var project = await _db.Projects
            .Include(p => p.Owner)
            .Include(p => p.Tasks)
            .Where(p => p.Id == id)
            .Select(p => new ProjectResponse(
                p.Id,
                p.Name,
                p.Description,
                p.Status,
                p.OwnerId,
                p.Owner!.DisplayName,
                p.Tasks.Count,
                p.CreatedAt
            ))
            .FirstOrDefaultAsync();

        if (project == null) return NotFound();
        return Ok(project);
    }

    [HttpPost]
    public async Task<ActionResult<ProjectResponse>> CreateProject(CreateProjectRequest request)
    {
        var userId = GetUserId();
        
        var project = new Project
        {
            Name = request.Name,
            Description = request.Description,
            OwnerId = userId
        };

        _db.Projects.Add(project);
        await _db.SaveChangesAsync();

        // Add owner as a member
        _db.ProjectMembers.Add(new ProjectMember
        {
            ProjectId = project.Id,
            UserId = userId,
            Role = "Owner"
        });
        await _db.SaveChangesAsync();

        var user = await _db.Users.FindAsync(userId);
        
        return CreatedAtAction(nameof(GetProject), new { id = project.Id },
            new ProjectResponse(project.Id, project.Name, project.Description, 
                project.Status, project.OwnerId, user!.DisplayName, 0, project.CreatedAt));
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateProject(int id, UpdateProjectRequest request)
    {
        var project = await _db.Projects.FindAsync(id);
        if (project == null) return NotFound();

        if (request.Name != null) project.Name = request.Name;
        if (request.Description != null) project.Description = request.Description;
        if (request.Status != null) project.Status = request.Status;
        project.UpdatedAt = DateTime.UtcNow;

        await _db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteProject(int id)
    {
        var project = await _db.Projects.FindAsync(id);
        if (project == null) return NotFound();

        _db.Projects.Remove(project);
        await _db.SaveChangesAsync();
        return NoContent();
    }

    [HttpGet("{id}/members")]
    public async Task<ActionResult<IEnumerable<UserResponse>>> GetMembers(int id)
    {
        var members = await _db.ProjectMembers
            .Where(pm => pm.ProjectId == id)
            .Include(pm => pm.User)
            .Select(pm => new UserResponse(pm.User!.Id, pm.User.Email, pm.User.DisplayName))
            .ToListAsync();

        return Ok(members);
    }
}
