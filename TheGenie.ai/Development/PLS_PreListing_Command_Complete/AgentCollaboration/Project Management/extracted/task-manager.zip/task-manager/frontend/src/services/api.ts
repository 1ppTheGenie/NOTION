import axios from 'axios';
import type { Task, Project, TaskStatus, User, AuthResponse } from '../types';

const api = axios.create({
  baseURL: 'http://localhost:5000/api',
});

// Add token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Handle 401 errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export const authApi = {
  login: async (email: string, password: string): Promise<AuthResponse> => {
    const { data } = await api.post('/auth/login', { email, password });
    return data;
  },
  register: async (email: string, displayName: string, password: string): Promise<AuthResponse> => {
    const { data } = await api.post('/auth/register', { email, displayName, password });
    return data;
  },
};

export const projectApi = {
  getAll: async (): Promise<Project[]> => {
    const { data } = await api.get('/projects');
    return data;
  },
  get: async (id: number): Promise<Project> => {
    const { data } = await api.get(`/projects/${id}`);
    return data;
  },
  create: async (name: string, description?: string): Promise<Project> => {
    const { data } = await api.post('/projects', { name, description });
    return data;
  },
  delete: async (id: number): Promise<void> => {
    await api.delete(`/projects/${id}`);
  },
};

export const taskApi = {
  getByProject: async (projectId: number): Promise<Task[]> => {
    const { data } = await api.get(`/tasks/project/${projectId}`);
    return data;
  },
  create: async (task: {
    title: string;
    description?: string;
    projectId: number;
    statusId?: number;
    assigneeId?: number;
    priority?: number;
    dueDate?: string;
  }): Promise<Task> => {
    const { data } = await api.post('/tasks', task);
    return data;
  },
  update: async (id: number, updates: Partial<Task>): Promise<void> => {
    await api.put(`/tasks/${id}`, updates);
  },
  move: async (id: number, newStatusId: number, newOrder: number): Promise<void> => {
    await api.put(`/tasks/${id}/move`, { newStatusId, newOrder });
  },
  delete: async (id: number): Promise<void> => {
    await api.delete(`/tasks/${id}`);
  },
};

export const statusApi = {
  getAll: async (): Promise<TaskStatus[]> => {
    const { data } = await api.get('/statuses');
    return data;
  },
};

export const userApi = {
  getAll: async (): Promise<User[]> => {
    const { data } = await api.get('/users');
    return data;
  },
  me: async (): Promise<User> => {
    const { data } = await api.get('/users/me');
    return data;
  },
};

export default api;
