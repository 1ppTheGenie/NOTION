# Task Manager - Localhost Setup

A simple Kanban-style task manager with .NET 8 API + React frontend, connecting to your MSSQL database.

## Quick Start

### Prerequisites
- .NET 8 SDK
- Node.js 18+
- SQL Server (local or remote)

---

## Step 1: Setup Database

1. Open SQL Server Management Studio (SSMS)
2. Connect to your SQL Server instance
3. Run the `database/schema.sql` script

This creates:
- `TaskManager` database
- All required tables
- Default admin user: `admin@localhost` / `admin123`

---

## Step 2: Configure Backend

1. Navigate to the backend folder:
   ```bash
   cd backend
   ```

2. Edit `appsettings.json` and update your connection string:
   ```json
   "ConnectionStrings": {
     "DefaultConnection": "Server=YOUR_SERVER;Database=TaskManager;User Id=YOUR_USER;Password=YOUR_PASSWORD;TrustServerCertificate=True;"
   }
   ```

   **Examples:**
   - Local with SQL Auth: `Server=localhost;Database=TaskManager;User Id=sa;Password=YourPassword;TrustServerCertificate=True;`
   - Local with Windows Auth: `Server=localhost;Database=TaskManager;Integrated Security=True;TrustServerCertificate=True;`
   - Named Instance: `Server=localhost\\SQLEXPRESS;Database=TaskManager;Integrated Security=True;TrustServerCertificate=True;`

3. Restore packages and run:
   ```bash
   dotnet restore
   dotnet run
   ```

4. API will be available at:
   - http://localhost:5000
   - Swagger UI: http://localhost:5000/swagger

---

## Step 3: Setup Frontend

1. Open a new terminal and navigate to frontend folder:
   ```bash
   cd frontend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the dev server:
   ```bash
   npm run dev
   ```

4. Open http://localhost:3000 in your browser

---

## Step 4: Login

Use the default credentials:
- **Email:** admin@localhost
- **Password:** admin123

Or register a new account.

---

## Project Structure

```
task-manager/
├── database/
│   └── schema.sql          # Run this first
├── backend/
│   ├── Controllers/        # API endpoints
│   ├── Models/             # Entity models
│   ├── Data/               # DbContext
│   ├── Services/           # Business logic
│   ├── DTOs/               # Request/Response objects
│   └── appsettings.json    # <-- Update connection string here
└── frontend/
    ├── src/
    │   ├── components/     # React components
    │   ├── pages/          # Page components
    │   ├── services/       # API client
    │   └── types/          # TypeScript types
    └── package.json
```

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/auth/login | Login |
| POST | /api/auth/register | Register new user |
| GET | /api/projects | List projects |
| POST | /api/projects | Create project |
| DELETE | /api/projects/{id} | Delete project |
| GET | /api/tasks/project/{id} | Get tasks for project |
| POST | /api/tasks | Create task |
| PUT | /api/tasks/{id} | Update task |
| PUT | /api/tasks/{id}/move | Move task (drag & drop) |
| DELETE | /api/tasks/{id} | Delete task |
| GET | /api/statuses | Get all statuses |
| GET | /api/users | List all users |

---

## Features

- ✅ JWT Authentication
- ✅ Multiple Projects
- ✅ Kanban Board with drag-and-drop
- ✅ Task priorities (Low, Medium, High, Urgent)
- ✅ Due dates
- ✅ User assignment
- ✅ MSSQL database

---

## Troubleshooting

### "Login failed for user"
- Check your connection string in `appsettings.json`
- Verify the SQL user has access to the TaskManager database

### "Connection refused" on frontend
- Make sure the backend is running on port 5000
- Check CORS settings if using different ports

### Tasks not dragging
- Make sure you're clicking and holding on the task card
- Check browser console for errors

---

## Next Steps (Optional Enhancements)

1. **Add more task fields** - Edit the backend models and database
2. **Task comments** - Already have the table, just need UI
3. **File attachments** - Add blob storage
4. **Email notifications** - Add SMTP config
5. **Deploy to Azure** - Use App Service + Azure SQL

---

## License

MIT - Use however you want for One Park Place.
