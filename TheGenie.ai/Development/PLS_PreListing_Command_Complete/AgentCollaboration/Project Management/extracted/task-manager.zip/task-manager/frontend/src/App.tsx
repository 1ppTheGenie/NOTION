import { Routes, Route, Navigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Board from './pages/Board';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    setIsAuthenticated(!!token);
  }, []);

  const handleLogin = (token: string) => {
    localStorage.setItem('token', token);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setIsAuthenticated(false);
  };

  if (isAuthenticated === null) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <Routes>
      <Route 
        path="/login" 
        element={
          isAuthenticated 
            ? <Navigate to="/" replace /> 
            : <Login onLogin={handleLogin} />
        } 
      />
      <Route 
        path="/" 
        element={
          isAuthenticated 
            ? <Dashboard onLogout={handleLogout} /> 
            : <Navigate to="/login" replace />
        } 
      />
      <Route 
        path="/project/:projectId" 
        element={
          isAuthenticated 
            ? <Board onLogout={handleLogout} /> 
            : <Navigate to="/login" replace />
        } 
      />
    </Routes>
  );
}

export default App;
