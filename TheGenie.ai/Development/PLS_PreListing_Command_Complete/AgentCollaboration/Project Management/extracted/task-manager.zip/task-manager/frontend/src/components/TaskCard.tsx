import { useDraggable } from '@dnd-kit/core';
import { CSS } from '@dnd-kit/utilities';
import type { Task } from '../types';
import { Calendar, User, AlertCircle } from 'lucide-react';

interface TaskCardProps {
  task: Task;
  onClick: () => void;
  isDragging?: boolean;
}

const priorityConfig: Record<number, { label: string; color: string; border: string }> = {
  1: { label: 'Low', color: 'text-gray-400', border: 'border-l-gray-300' },
  2: { label: 'Medium', color: 'text-blue-500', border: 'border-l-blue-400' },
  3: { label: 'High', color: 'text-orange-500', border: 'border-l-orange-400' },
  4: { label: 'Urgent', color: 'text-red-500', border: 'border-l-red-500' },
};

export default function TaskCard({ task, onClick, isDragging }: TaskCardProps) {
  const { attributes, listeners, setNodeRef, transform } = useDraggable({
    id: task.id,
  });

  const style = transform ? {
    transform: CSS.Translate.toString(transform),
  } : undefined;

  const priority = priorityConfig[task.priority] || priorityConfig[2];
  const isOverdue = task.dueDate && new Date(task.dueDate) < new Date();

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      onClick={onClick}
      className={`
        bg-white rounded-lg shadow-sm p-3 cursor-pointer
        border-l-4 ${priority.border}
        hover:shadow-md transition-shadow
        ${isDragging ? 'opacity-90 shadow-lg rotate-2' : ''}
      `}
    >
      <h4 className="font-medium text-gray-900 mb-1 line-clamp-2">{task.title}</h4>
      
      {task.description && (
        <p className="text-sm text-gray-500 mb-3 line-clamp-2">
          {task.description}
        </p>
      )}

      <div className="flex items-center justify-between text-xs">
        <div className="flex items-center gap-3">
          {task.dueDate && (
            <span className={`flex items-center gap-1 ${isOverdue ? 'text-red-500' : 'text-gray-400'}`}>
              <Calendar className="w-3 h-3" />
              {new Date(task.dueDate).toLocaleDateString()}
            </span>
          )}
          
          {task.priority >= 3 && (
            <span className={`flex items-center gap-1 ${priority.color}`}>
              <AlertCircle className="w-3 h-3" />
              {priority.label}
            </span>
          )}
        </div>
        
        {task.assigneeName && (
          <span className="flex items-center gap-1 text-gray-400">
            <User className="w-3 h-3" />
            {task.assigneeName.split(' ')[0]}
          </span>
        )}
      </div>
    </div>
  );
}
