using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using TaskManager.Api.Data;
using TaskManager.Api.DTOs;
using TaskManager.Api.Models;

namespace TaskManager.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class TasksController : ControllerBase
{
    private readonly AppDbContext _db;

    public TasksController(AppDbContext db)
    {
        _db = db;
    }

    private int GetUserId() => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    [HttpGet("project/{projectId}")]
    public async Task<ActionResult<IEnumerable<TaskResponse>>> GetTasksByProject(int projectId)
    {
        var tasks = await _db.Tasks
            .Where(t => t.ProjectId == projectId)
            .Include(t => t.Status)
            .Include(t => t.Assignee)
            .OrderBy(t => t.StatusId)
            .ThenBy(t => t.DisplayOrder)
            .Select(t => new TaskResponse(
                t.Id,
                t.Title,
                t.Description,
                t.ProjectId,
                t.StatusId,
                t.Status!.Name,
                t.Status.Color,
                t.AssigneeId,
                t.Assignee != null ? t.Assignee.DisplayName : null,
                t.Priority,
                t.DueDate,
                t.DisplayOrder,
                t.CreatedAt
            ))
            .ToListAsync();

        return Ok(tasks);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<TaskResponse>> GetTask(int id)
    {
        var task = await _db.Tasks
            .Include(t => t.Status)
            .Include(t => t.Assignee)
            .Where(t => t.Id == id)
            .Select(t => new TaskResponse(
                t.Id,
                t.Title,
                t.Description,
                t.ProjectId,
                t.StatusId,
                t.Status!.Name,
                t.Status.Color,
                t.AssigneeId,
                t.Assignee != null ? t.Assignee.DisplayName : null,
                t.Priority,
                t.DueDate,
                t.DisplayOrder,
                t.CreatedAt
            ))
            .FirstOrDefaultAsync();

        if (task == null) return NotFound();
        return Ok(task);
    }

    [HttpPost]
    public async Task<ActionResult<TaskResponse>> CreateTask(CreateTaskRequest request)
    {
        var task = new TaskItem
        {
            Title = request.Title,
            Description = request.Description,
            ProjectId = request.ProjectId,
            StatusId = request.StatusId ?? 1,
            AssigneeId = request.AssigneeId,
            Priority = request.Priority ?? 2,
            DueDate = request.DueDate,
            CreatedById = GetUserId()
        };

        _db.Tasks.Add(task);
        await _db.SaveChangesAsync();

        // Reload with includes
        await _db.Entry(task).Reference(t => t.Status).LoadAsync();
        await _db.Entry(task).Reference(t => t.Assignee).LoadAsync();

        return CreatedAtAction(nameof(GetTask), new { id = task.Id },
            new TaskResponse(
                task.Id,
                task.Title,
                task.Description,
                task.ProjectId,
                task.StatusId,
                task.Status!.Name,
                task.Status.Color,
                task.AssigneeId,
                task.Assignee?.DisplayName,
                task.Priority,
                task.DueDate,
                task.DisplayOrder,
                task.CreatedAt
            ));
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateTask(int id, UpdateTaskRequest request)
    {
        var task = await _db.Tasks.FindAsync(id);
        if (task == null) return NotFound();

        if (request.Title != null) task.Title = request.Title;
        if (request.Description != null) task.Description = request.Description;
        if (request.StatusId.HasValue) task.StatusId = request.StatusId.Value;
        if (request.AssigneeId.HasValue) task.AssigneeId = request.AssigneeId.Value;
        if (request.Priority.HasValue) task.Priority = request.Priority.Value;
        if (request.DueDate.HasValue) task.DueDate = request.DueDate.Value;
        task.UpdatedAt = DateTime.UtcNow;

        await _db.SaveChangesAsync();
        return NoContent();
    }

    [HttpPut("{id}/move")]
    public async Task<IActionResult> MoveTask(int id, MoveTaskRequest request)
    {
        var task = await _db.Tasks.FindAsync(id);
        if (task == null) return NotFound();

        task.StatusId = request.NewStatusId;
        task.DisplayOrder = request.NewOrder;
        task.UpdatedAt = DateTime.UtcNow;

        await _db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteTask(int id)
    {
        var task = await _db.Tasks.FindAsync(id);
        if (task == null) return NotFound();

        _db.Tasks.Remove(task);
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
