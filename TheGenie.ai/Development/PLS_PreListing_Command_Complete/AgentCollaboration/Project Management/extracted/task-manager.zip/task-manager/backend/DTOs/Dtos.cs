namespace TaskManager.Api.DTOs;

// Auth DTOs
public record LoginRequest(string Email, string Password);
public record RegisterRequest(string Email, string DisplayName, string Password);
public record AuthResponse(string Token, int UserId, string Email, string DisplayName);

// Task DTOs
public record CreateTaskRequest(
    string Title,
    string? Description,
    int ProjectId,
    int? StatusId,
    int? AssigneeId,
    int? Priority,
    DateTime? DueDate
);

public record UpdateTaskRequest(
    string? Title,
    string? Description,
    int? StatusId,
    int? AssigneeId,
    int? Priority,
    DateTime? DueDate
);

public record MoveTaskRequest(int NewStatusId, int NewOrder);

// Project DTOs
public record CreateProjectRequest(string Name, string? Description);
public record UpdateProjectRequest(string? Name, string? Description, string? Status);

// Response DTOs
public record TaskResponse(
    int Id,
    string Title,
    string? Description,
    int ProjectId,
    int StatusId,
    string StatusName,
    string StatusColor,
    int? AssigneeId,
    string? AssigneeName,
    int Priority,
    DateTime? DueDate,
    int DisplayOrder,
    DateTime CreatedAt
);

public record ProjectResponse(
    int Id,
    string Name,
    string? Description,
    string Status,
    int OwnerId,
    string OwnerName,
    int TaskCount,
    DateTime CreatedAt
);

public record UserResponse(int Id, string Email, string DisplayName);
