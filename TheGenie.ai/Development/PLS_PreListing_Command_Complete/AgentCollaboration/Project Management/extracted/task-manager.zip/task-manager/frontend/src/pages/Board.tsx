import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { DndContext, closestCorners, DragEndEvent, DragStartEvent, DragOverlay } from '@dnd-kit/core';
import { taskApi, statusApi, projectApi, userApi } from '../services/api';
import type { Task, TaskStatus, Project, User } from '../types';
import Column from '../components/Column';
import TaskCard from '../components/TaskCard';
import TaskModal from '../components/TaskModal';
import { ArrowLeft, LogOut, Plus } from 'lucide-react';

interface BoardProps {
  onLogout: () => void;
}

export default function Board({ onLogout }: BoardProps) {
  const { projectId } = useParams<{ projectId: string }>();
  const navigate = useNavigate();
  
  const [project, setProject] = useState<Project | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [statuses, setStatuses] = useState<TaskStatus[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTask, setActiveTask] = useState<Task | null>(null);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [showNewTask, setShowNewTask] = useState(false);
  const [newTaskStatusId, setNewTaskStatusId] = useState<number>(1);

  useEffect(() => {
    if (projectId) loadData();
  }, [projectId]);

  const loadData = async () => {
    try {
      const [projectData, tasksData, statusesData, usersData] = await Promise.all([
        projectApi.get(parseInt(projectId!)),
        taskApi.getByProject(parseInt(projectId!)),
        statusApi.getAll(),
        userApi.getAll()
      ]);
      setProject(projectData);
      setTasks(tasksData);
      setStatuses(statusesData);
      setUsers(usersData);
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDragStart = (event: DragStartEvent) => {
    const task = tasks.find(t => t.id === event.active.id);
    setActiveTask(task || null);
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    setActiveTask(null);

    if (!over) return;

    const taskId = active.id as number;
    const overId = over.id as string | number;
    
    // Determine the new status - could be dropping on a column or another task
    let newStatusId: number;
    
    if (typeof overId === 'string' && overId.startsWith('column-')) {
      newStatusId = parseInt(overId.replace('column-', ''));
    } else {
      // Dropped on a task, get that task's status
      const targetTask = tasks.find(t => t.id === overId);
      if (!targetTask) return;
      newStatusId = targetTask.statusId;
    }

    const task = tasks.find(t => t.id === taskId);
    if (!task || task.statusId === newStatusId) return;

    // Optimistically update UI
    setTasks(tasks.map(t => 
      t.id === taskId ? { ...t, statusId: newStatusId } : t
    ));

    try {
      await taskApi.move(taskId, newStatusId, 0);
    } catch (error) {
      // Revert on error
      setTasks(tasks);
      console.error('Failed to move task:', error);
    }
  };

  const createTask = async (title: string, description: string) => {
    try {
      const newTask = await taskApi.create({
        title,
        description,
        projectId: parseInt(projectId!),
        statusId: newTaskStatusId
      });
      setTasks([...tasks, newTask]);
      setShowNewTask(false);
    } catch (error) {
      console.error('Failed to create task:', error);
    }
  };

  const updateTask = async (taskId: number, updates: Partial<Task>) => {
    try {
      await taskApi.update(taskId, updates);
      setTasks(tasks.map(t => t.id === taskId ? { ...t, ...updates } : t));
      setSelectedTask(null);
    } catch (error) {
      console.error('Failed to update task:', error);
    }
  };

  const deleteTask = async (taskId: number) => {
    try {
      await taskApi.delete(taskId);
      setTasks(tasks.filter(t => t.id !== taskId));
      setSelectedTask(null);
    } catch (error) {
      console.error('Failed to delete task:', error);
    }
  };

  const openNewTask = (statusId: number) => {
    setNewTaskStatusId(statusId);
    setShowNewTask(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm flex-shrink-0">
        <div className="px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/')}
              className="text-gray-500 hover:text-gray-700 p-2 rounded-lg hover:bg-gray-100 transition"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-gray-900">{project?.name}</h1>
              {project?.description && (
                <p className="text-sm text-gray-500">{project.description}</p>
              )}
            </div>
          </div>
          <button
            onClick={onLogout}
            className="text-gray-500 hover:text-gray-700 p-2 rounded-lg hover:bg-gray-100 transition"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Kanban Board */}
      <div className="flex-1 overflow-x-auto p-6">
        <DndContext
          collisionDetection={closestCorners}
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
        >
          <div className="flex gap-4 h-full min-w-max">
            {statuses.map((status) => (
              <Column
                key={status.id}
                status={status}
                tasks={tasks.filter(t => t.statusId === status.id)}
                onTaskClick={setSelectedTask}
                onAddClick={() => openNewTask(status.id)}
              />
            ))}
          </div>
          
          <DragOverlay>
            {activeTask && (
              <TaskCard task={activeTask} onClick={() => {}} isDragging />
            )}
          </DragOverlay>
        </DndContext>
      </div>

      {/* Task Modal */}
      {(selectedTask || showNewTask) && (
        <TaskModal
          task={selectedTask}
          statuses={statuses}
          users={users}
          onClose={() => {
            setSelectedTask(null);
            setShowNewTask(false);
          }}
          onSave={(title, description) => {
            if (selectedTask) {
              updateTask(selectedTask.id, { title, description });
            } else {
              createTask(title, description);
            }
          }}
          onDelete={selectedTask ? () => deleteTask(selectedTask.id) : undefined}
        />
      )}
    </div>
  );
}
