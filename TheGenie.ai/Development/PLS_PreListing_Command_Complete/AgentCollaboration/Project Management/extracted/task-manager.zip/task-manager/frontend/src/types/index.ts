export interface User {
  id: number;
  email: string;
  displayName: string;
}

export interface Project {
  id: number;
  name: string;
  description?: string;
  status: string;
  ownerId: number;
  ownerName: string;
  taskCount: number;
  createdAt: string;
}

export interface TaskStatus {
  id: number;
  name: string;
  displayOrder: number;
  color: string;
}

export interface Task {
  id: number;
  title: string;
  description?: string;
  projectId: number;
  statusId: number;
  statusName: string;
  statusColor: string;
  assigneeId?: number;
  assigneeName?: string;
  priority: number;
  dueDate?: string;
  displayOrder: number;
  createdAt: string;
}

export interface AuthResponse {
  token: string;
  userId: number;
  email: string;
  displayName: string;
}
