using System.ComponentModel.DataAnnotations;

namespace TaskManager.Api.Models;

public class TaskStatus
{
    public int Id { get; set; }
    
    [Required, MaxLength(50)]
    public string Name { get; set; } = string.Empty;
    
    public int DisplayOrder { get; set; }
    
    [MaxLength(7)]
    public string Color { get; set; } = "#6B7280";
}
